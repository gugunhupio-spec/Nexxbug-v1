NEXX BUILDER PROMPT PACK

1. Ekstrak ZIP.
2. Buka MASTER_PROMPT_NEXX_BUILDER.txt.
3. Salin seluruh prompt ke AI coding assistant.

Catatan: APK sungguhan memerlukan VPS/komputer Linux dengan JDK, Android SDK, dan Gradle terpasang.
